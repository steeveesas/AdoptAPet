//JUst a file to place any javascript constants we want to reference throughout our program

//A hardcoded value for this test to ensure only 6 pets are shown at most in the grid even when results return more than 6 pets
const MAX_PETS_IN_GRID = 6;
//Default Test URL given in instructions
const DEFAULT_TEST_URL = "https://api.adoptapet.com/search/pet_search?key=e41b6bf1618d053c31d524d235j9hj7&geo_range=50&city_or_zip=47374&species=dog&output=json";
//API Key given in test instructions
const API_KEY = "e41b6bf1618d053c31d524d235j9hj7";