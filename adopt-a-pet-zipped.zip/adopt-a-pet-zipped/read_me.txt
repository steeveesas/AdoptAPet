To run the code:
- download and unzip "adopt-a-pet-zipped.zip".
- go to hmtl directory and open index.html in your browser.
- The webpage will open and begin a search automatically...you will need to be connected to the internet.
- Refresh the page to re-run the search

Developer Notes:
The code seems functional to me. 
The styling however is not close to finished. I had a tough time getting spun up with
Tailwind and was spending a lot of time trying to make things work but couldn't in the allotted time.
Many, many, many of the spec requirements are not met, if there weren't so many I would enumerate them
here to show I know what remains to be done.
A few notable things, the picture sizes are not fixed at various intervals instead they shrink at a constant rate
until we get to the mobile screen size.
Many of the elements overlap each other and look messy as the window is resized. It's not pretty.

I will say it was a fun challenge and was left wanting to know more about Windtail and how to use it better...same with Alpine.
Thanks!

- Steve